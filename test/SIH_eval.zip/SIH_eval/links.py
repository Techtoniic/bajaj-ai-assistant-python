import pandas as pd
import os

dir = os.listdir()
print(dir)

for i in dir:
    if i.contains('.jpeg')
